<template>
    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" :width="width" :height="width" viewBox="0 0 15 15" fill="none">
        <rect width="15" height="15" fill="url(#pattern0)"/>
        <defs>
        <pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1">
        <use xlink:href="#image0_5788_2548" transform="scale(0.0333333)"/>
        </pattern>
        <image id="image0_5788_2548" width="30" height="30" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAABmJLR0QA/wD/AP+gvaeTAAABXklEQVRIie3WPU7DMBgG4PcrHRAMMMMRmJA4RNWINhITGxwBCZEsqI7E0IY7wMRU1EaAUTdWBlaOgMTKxELzMVSRUpMYN7E79d0S23n8E8cBVllSyMVDQ9k9Y9AlAx9Aehp7D2/O4VD6goFe7tYXU6MVt0ev+XoN23BBtojTyYXsHDiF+14iCIhUHGjcWodD6YtQ+kKHE7BjFc7WlIGeDifwldKR+qjywKjvJSJfJ+uIFbgIzcJEg7g9DnXtK8E61BRfeI1N0JnM37rihUZsijIgYi9Rt1Q12CZqDNtGjWAX6L+wK1QLu0QBzXbitekQRGNdYwKiKqgWHrQe31PGTWnHAKF+Bq3AszT//DlkaNWRGsHX3vCTf9JdEHeyaa8zvaURLyfrwVP3vKgsmBzu5Y+9upl7q0PpHzFwb3K61M3cVDNwDADEHJSN3FaayvU+gBEz3W1sbj+7hFdZWn4BP5mn2nIMSYMAAAAASUVORK5CYII="/>
        </defs>
</svg>
</template>

<script>
   import Vue from 'vue'
   export default Vue.extend({
        props:['width']
    })
</script>

<style scoped>

</style>