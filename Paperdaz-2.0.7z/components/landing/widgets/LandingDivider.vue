<template>
  <div class="h-6 bg-paperdazgreen-500"></div>
</template>
<script>
import Vue from 'vue'

export default Vue.extend({
  name: 'LandingDivider',
})
</script>