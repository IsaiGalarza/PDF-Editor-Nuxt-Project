<template>
  <div class="signature-pad" ref="signature-pad">
    <canvas height="176" ref="signature-pad-canvas" width="656" />
  </div>
</template>

<script>
// import SignaturePad from "signature_pad"
export default {
  methods: {
    // initializeSignaturePad() {
    //   const canvasSig = this.$refs['signature-pad-canvas']
    //   this.signaturePad = new SignaturePad(canvasSig, {
    //     backgroundColor: "rgb(255, 255, 255, 0)",
    //   });
    // }
  },
}
</script>

<style></style>
