export default {
  left: 'left',
  right: 'right',
}
