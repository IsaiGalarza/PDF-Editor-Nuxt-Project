<template>
   <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" :width="width" :height="width" viewBox="0 0 41 40" fill="none">
        <rect x="0.463379" width="40" height="40" fill="url(#pattern0)"/>
        <defs>
        <pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1">
        <use xlink:href="#image0_3611_2532" transform="scale(0.02)"/>
        </pattern>
        <image id="image0_3611_2532" width="50" height="50" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAAGTklEQVRoge2ZW2xcVxWGv73PmYud8S2JE5NCQpwmNbGLlBZQoaUPiMtDG1KlqAJCiRQJBYFolAcqgZQH+gZSH1KBUOAhqKpQVCFBW7VCjVCFQAkXVU3T4gYnDgm0zmVqx3YylzNzzl48zOVcPfbEI0Bi1oPP7HXW+df6115773WOoStd6UpXutKVrqBCoxfyd6H1PkRt/M+4F5AEtYlcgwMBFNdQPMfe4anGXZ/IS7OfBPU7oKfD0foBNH5IRCcSt0vUBQZCCWM+w5dH/gSgfWv9FJ0mIfWAjPhXk6CTuu2yurq+htGDUk81XNkBrxMdCTxaLqvL+nK4zZgDRLDajbtluSTq8INfNvAV4TbjDxJpI/jbyHrMPgmjTdyAenki7Wa9VWnEdO3gLlWGrYisJDutyqUlxjK6ZXETdCEiSwF2YpHGdB3EjRMxICqZTNBJuzPR7uJvGzdKxEQNI9kRqesElPbtjPGfUzrsxHgBV417Ukta0C6a9Sa+1PGhdnZHEp1IpBFslK0IeFXWVgtszVksOIYLjg3ZXigVGM24DKUt5soe/3BTkKqfqU6J0VSFoYzFvOMxXbYgswaqDiOqxB29diKZSzcrzOo+sGxwSmzQDrmU4kpJKKVyoCz/gcTFbiQEGCJTLPLqw3dw73AvRmD8+Qucq7pYlTLnHh8jpRUVT9j2yyne9dIgwqjt8Pev7MDWCk+E3M8mKad6wCnzyt7N7NrQG08rMDlb4oFfTXOjkuWBdYZX945RdoX7TkwxVTGgI7Men5El6tqt8uBazb3Dvfxtrsz42iyHJwY5+OcFlEBKK6pGSFuKJ8YHefJMEYzh0MeGsLXCCFhK1U7benuSthSOJzzx2j9DwXzqAzn2j6/jNw9t4bu/f4+X9mxHBB7+9QWmimlI2f4SaODVxe+1oj2QSE1XLnP47nUI8NhvLzG94LB/bB0bdbVZim/ki1yYdzg4sZ5+r8iQOBwYX897t6r85WohkCg/WSLCxfkKFxddLi64nJ+vcuDkvzhxbo4HP9jH6a+OsSaleezFaU7NKrDT8X4rwMQn0ghcqDd3Ap7LaMZj99Z+/jhziysFl2fPzZGxFAfHBsCrReUZeObMdfrTFgd2DPDNnQPkUpqjb1zD8QILu4ELZG3NyS9t5+TebZx8dBsvfnEUI5rv/2GGqhG0glem53n5cgnsrJ/oUMOZVFqhNVKXisN3dg1iKcWnN+WY+4bfV37ro+t5+vVrzfHxyTl+cN8mDu0aJq01C47HsbdmeWjrgI9f3/QQKLmGieOTzZo3RhjULi88Ultz75dc9mwf4tsTi/xkslDbKJK28hiR4K5VQ6bfK3Fg52Yu36zw07P55sP3b8qxe3SAfXcNNR++ZWx+/laeJz8+AsCP/nqVRdcKr7vmFg5aKT67ORcK5uvjW7h7uJcfnp7h2JuznH58jKOf28ylhSlefrcI6Z5wsgPxxmekYVCtsv/OPvrTFkdOXeGZKae2JYrwofMzfH5LP4fvqb1IFqsG0Pz47ByH7tmIEeHomVlQFsWqoeIJrvFLouQaMpbi2Bc+TFSOn83zvVOziJ1h9/NTvPa1j3Biz5184hfv8E7Z9bffyIz4b4jPzlxHGG6OXZd+9yZrM5rLBZCePpoHklNiWDv0pWsH1/WSxy29BozLsK4gAu+bNGibNe5Nei1N3kvXMlqp0C8F1meDr0K1P8YIlwoGsn2AhkqJIeUwlLGYKRrKqVz9sGwugzyHRzdEZiRAUwBtsWgPsOgJ9Kjw+ZLqIS8Z8tW6va1AKdAp8pKp8dW1HBXsQQoIpFRtRuwUi2aAxaoQqvXGNRvwZWe5IWluVKTmAxU/7+oSPkeCBk0HKl6T0phM5euapaniGKh4C4QisbeL+Wq0JiRvSDEioTUSAQvpAoOV6ELtTivcVfgi1sYHAEMBrECXtDW21HUIN05E4mRigEkZ7lDWV4NLqwNxyWmNOGk36x3BjZAktmslGN1u1leEcRu+kpJE9A0RtfJMdGxDWCVunAhe/OFVLNIkjM7junEihreBkf/5jw2hmVBvx4mIHEG4n8b33//6x4bkEgpIEdSRxiD8b4Wnp3dgsQ9RI0uCNF5oTMI9SVCapN8tgkzCjRtdRclzHNl5fiXWXelKV7rSla7838i/Aa9tXRYG5IxmAAAAAElFTkSuQmCC"/>
        </defs>
</svg>
</template>

<script>
    export default {
        name:"americanexpress-icon",
        props:['width']
    }
</script>

<style scoped>

</style>