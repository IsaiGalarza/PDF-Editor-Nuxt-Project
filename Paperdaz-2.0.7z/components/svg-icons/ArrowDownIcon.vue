<template>
  <svg
    width="19"
    height="12"
    viewBox="0 0 19 12"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M16.793 0.740234L18.2072 2.18897L9.50008 11.1087L0.792969 2.18897L2.20718 0.740234L9.50008 8.21118L16.793 0.740234Z"
      fill="currentColor"
    />
  </svg>
</template>
<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'ArrowDownIcon',
})
</script>
