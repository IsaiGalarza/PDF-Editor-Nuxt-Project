<template>
  <svg
    width="17"
    height="20"
    viewBox="0 0 17 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="fill-current"
  >
    <path
      d="M8.20513 20C9.33333 20 10.2564 19.0769 10.2564 17.9487H6.15385C6.15385 19.0769 7.06667 20 8.20513 20ZM14.359 13.8462V8.71795C14.359 5.56923 12.6769 2.93333 9.74359 2.2359V1.53846C9.74359 0.68718 9.05641 0 8.20513 0C7.35385 0 6.66667 0.68718 6.66667 1.53846V2.2359C3.72308 2.93333 2.05128 5.55897 2.05128 8.71795V13.8462L0 15.8974V16.9231H16.4103V15.8974L14.359 13.8462Z"
    />
  </svg>
</template>

<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'BellIcon',
})
</script>
