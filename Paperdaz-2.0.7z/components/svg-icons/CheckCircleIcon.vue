<template>
  <svg
    width="15"
    height="15"
    viewBox="0 0 15 15"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="fill-current"
  >
    <path
      d="M7.50002 0.416656C3.59002 0.416656 0.416687 3.58999 0.416687 7.49999C0.416687 11.41 3.59002 14.5833 7.50002 14.5833C11.41 14.5833 14.5834 11.41 14.5834 7.49999C14.5834 3.58999 11.41 0.416656 7.50002 0.416656ZM6.08335 11.0417L2.54169 7.49999L3.54044 6.50124L6.08335 9.03707L11.4596 3.66082L12.4584 4.66666L6.08335 11.0417Z"
    />
  </svg>
</template>

<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'CheckCircleIcon',
})
</script>
