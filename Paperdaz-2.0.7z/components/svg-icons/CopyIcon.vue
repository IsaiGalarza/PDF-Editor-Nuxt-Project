<template>
  <svg
    width="21"
    height="20"
    viewBox="0 0 21 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
  >
    <path
      d="M0.725586 9.84375C0.725586 4.4072 5.13278 0 10.5693 0H10.8039C16.2405 0 20.6477 4.4072 20.6477 9.84375V9.84375C20.6477 15.2803 16.2405 19.6875 10.8039 19.6875H10.5693C5.13278 19.6875 0.725586 15.2803 0.725586 9.84375V9.84375Z"
      fill="url(#pattern0)"
    />
    <defs>
      <pattern
        id="pattern0"
        patternContentUnits="objectBoundingBox"
        width="1"
        height="1"
      >
        <use
          xlink:href="#image0_3707_2255"
          transform="translate(0.00588822) scale(0.0329408 0.0333333)"
        />
      </pattern>
      <image
        id="image0_3707_2255"
        width="30"
        height="30"
        xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAABmJLR0QA/wD/AP+gvaeTAAAAuklEQVRIie3WvQ6CMBSG4Vd3HbweL0Di5OAduGjC/TpbLoJF62BNSlPCaT12Ol/SkPDTB8IXKFjyOQID4BfGCFw1YSdAPfAK46YFS1APXIBnwPuWMNp4CVyNx0WqheFTsu87FxUuLlIpvJ/BxxRZZWCfOZ4+TU0m1lphwqoYbLDBBv8N3oTt8KPjJCfFH/1T2NchX4Wk4wEcSuE7sJNcpJH0jh1wBraayNJvUXPeSXLlalKkXJoUydIsb25KjTHUSBgsAAAAAElFTkSuQmCC"
      />
    </defs>
  </svg>
</template>
<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'CopyIcon',
})
</script>
