<template>
     <svg
             :width="width"
             :height="height"
              viewBox="0 0 41 38"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <g clip-path="url(#clip0_4286_11048)">
                <path
                  d="M30.1934 19.0029L30.5926 34.125"
                  stroke="#EBE330"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
                <path
                  d="M34.2064 21.6582L28.2942 21.8007C27.5624 21.8183 26.8674 22.0887 26.3619 22.5524C25.8564 23.016 25.5818 23.635 25.5987 24.2731C25.6155 24.9111 25.9224 25.5161 26.4517 25.9548C26.981 26.3935 27.6895 26.6301 28.4212 26.6124L32.3627 26.5175C33.0944 26.4998 33.8029 26.7364 34.3322 27.1751C34.8615 27.6138 35.1684 28.2188 35.1852 28.8569C35.2021 29.4949 34.9275 30.1139 34.422 30.5775C33.9165 31.0412 33.2215 31.3116 32.4897 31.3292L25.7893 31.4907"
                  stroke="#EBE330"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </g>
              <g clip-path="url(#clip1_4286_11048)">
                <path
                  d="M26.0182 5.95208L6.17721 13.6065C4.95967 14.0763 4.35687 15.4414 4.83082 16.6557L9.97983 29.8479C10.4538 31.0622 11.825 31.6658 13.0425 31.1961L22.6264 28.1312C19.3787 23.0597 20.7842 13.6633 32.7281 16.6448L29.0809 7.30028C28.6069 6.08597 27.2357 5.48236 26.0182 5.95208Z"
                  stroke="#EBE330"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
                <path
                  d="M6.81514 19.7875L18.3611 15.1254L24.1561 12.8491L29.907 10.4633"
                  stroke="#EBE330"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
                <path
                  d="M27.6024 7.57149C26.5217 5.93038 22.2046 8.2852 7.71295 14.1172C5.90803 14.8436 5.42703 17.2004 6.81027 18.6084L28.7766 9.93814L27.6024 7.57149Z"
                  fill="#EBE330"
                  stroke="#EBE330"
                />
              </g>
              <defs>
                <clipPath id="clip0_4286_11048">
                  <rect
                    width="18.9245"
                    height="16.5032"
                    fill="white"
                    transform="matrix(0.99971 -0.0240897 0.0263944 0.999652 20.7148 18.5439)"
                  />
                </clipPath>
                <clipPath id="clip1_4286_11048">
                  <rect
                    width="28.3758"
                    height="28.3021"
                    fill="white"
                    transform="matrix(0.932295 -0.359671 0.363861 0.932243 1.1543 10.4844)"
                  />
                </clipPath>
              </defs>
            </svg>
</template>

<script>
    export default {
        name:'creditIcon',
        props:['width','height']
    }
</script>

<style scoped>

</style>