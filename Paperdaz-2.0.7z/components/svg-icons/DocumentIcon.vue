<template>
  <svg
    width="17"
    height="22"
    viewBox="0 0 17 22"
    fill="none"
    class="fill-current"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M14.6766 0.490234H0.470703V19.6062H1.706V1.72352H14.6766V0.490234Z"
    />
    <path
      d="M2.94141 2.95898V21.4583H11.5884V16.5251H16.5296V2.95898H2.94141ZM9.7355 16.5251H5.41199V15.2918H9.7355V16.5251ZM14.059 14.0585H5.41199V12.8253H14.059V14.0585ZM14.059 11.592H5.41199V10.3587H14.059V11.592ZM14.059 9.12541H5.41199V7.89212H14.059V9.12541ZM14.059 6.65884H5.41199V5.42555H14.059V6.65884Z"
    />
    <path d="M12.8232 21.0935L16.1673 17.7549H12.8232V21.0935Z" />
  </svg>
</template>
<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'DocumentIcon',
})
</script>
