<template>
  <svg
    width="4"
    height="17"
    viewBox="0 0 4 17"
    fill="none"
    class="fill-current"
    xmlns="http://www.w3.org/2000/svg"
  >
    <ellipse cx="1.99991" cy="1.70001" rx="1.99991" ry="1.70001" />
    <ellipse cx="1.99991" cy="8.50079" rx="1.99991" ry="1.70001" />
    <ellipse cx="1.99991" cy="15.2996" rx="1.99991" ry="1.70001" />
  </svg>
</template>

<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'EllipsisIconVerticalIcon',
})
</script>
