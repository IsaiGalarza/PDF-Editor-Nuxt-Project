<template>
  <svg
    width="20"
    height="18"
    viewBox="0 0 20 18"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M7.52952 16.5003C6.94078 16.5003 7.04082 16.278 6.83776 15.7174L5.10645 10.0195L18.4334 2.11328"
      fill="#C8DAEA"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M7.5293 16.5003C7.98362 16.5003 8.18436 16.2925 8.43795 16.0459L10.861 13.6898L7.83854 11.8672"
      fill="#A9C9DD"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M7.83762 11.8693L15.1614 17.2802C15.9971 17.7413 16.6003 17.5026 16.8085 16.5043L19.7896 2.45603C20.0948 1.23234 19.3231 0.677338 18.5236 1.04032L1.01842 7.79025C-0.176479 8.26952 -0.169513 8.93615 0.800612 9.23319L5.29285 10.6353L15.6928 4.07405C16.1838 3.77633 16.6344 3.93639 16.2646 4.26463"
      fill="url(#paint0_linear_511_20)"
    />
    <defs>
      <linearGradient
        id="paint0_linear_511_20"
        x1="8.58545"
        y1="9.2889"
        x2="10.5272"
        y2="15.5699"
        gradientUnits="userSpaceOnUse"
      >
        <stop stop-color="#EFF7FC" />
        <stop offset="1" stop-color="white" />
      </linearGradient>
    </defs>
  </svg>
</template>

<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'EnvelopeIcon',
})
</script>
