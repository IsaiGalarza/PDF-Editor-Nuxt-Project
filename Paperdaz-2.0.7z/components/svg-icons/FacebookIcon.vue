<template>
  <svg
    width="11"
    height="20"
    viewBox="0 0 11 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="fill-current"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M7.06623 19.8578V9.97074H9.79551L10.1572 6.56358H7.06623L7.07087 4.85827C7.07087 3.96963 7.1553 3.49348 8.43164 3.49348H10.1379V0.0859375H7.40821C4.12945 0.0859375 2.97541 1.73877 2.97541 4.51832V6.56397H0.931641V9.97112H2.97541V19.8578H7.06623Z"
    />
  </svg>
</template>
<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'FacebookIcon',
})
</script>
