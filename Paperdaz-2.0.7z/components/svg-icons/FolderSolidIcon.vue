<template>
  <svg
    width="30"
    height="30"
    viewBox="0 0 30 30"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
  >
    <rect width="30" height="30" fill="url(#pattern0)" />
    <defs>
      <pattern
        id="pattern0"
        patternContentUnits="objectBoundingBox"
        width="1"
        height="1"
      >
        <use xlink:href="#image0_3848_19071" transform="scale(0.0333333)" />
      </pattern>
      <image
        id="image0_3848_19071"
        width="30"
        height="30"
        xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAABmJLR0QA/wD/AP+gvaeTAAABPklEQVRIie3SsUrDQBjA8f93Ci2+ggri7gtE8wQ+g1gHO3YSdBEyCBoQXO2gYFdBNApOKthJJ0VQKI4OZiyIikg+h2jaNNUpScH2v91xfD+OOxj035P2xfLl/CwiVWC0y8k71My59u5tGrDpGL7dFQVQpiA4cC5KxTTg+I3rJU1jaDJ9QrTsztROf3bMX8fTS8ZUTbV9JycYBMZ7AnfWM7j/EoCV+sKaoktAIWPvHXTTtfdWDYCilRxQgCJIBb4/l8BNDmiYhFZ4YxEvN1fVi2Ax5jA3GD2O4A1r5xHkIQf3ft2uNSI4TI+yVkVbRgQbE2T+zoFp/aUILliTV8Bzhq4/Mj1xnYAdcQIVPckQ9hxxggQMoGqye2eN/6EY/Dn0cobQTB0Vmh/Dr+e/wlvW/htoGfBTZH1RFsPZg/qpL4z0WxxCKWZhAAAAAElFTkSuQmCC"
      />
    </defs>
  </svg>
</template>

<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'FolderSolidIcon',
})
</script>
