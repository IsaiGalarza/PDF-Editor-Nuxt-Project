<template>
  <svg
    width="12"
    height="14"
    viewBox="0 0 12 14"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="stroke-current"
  >
    <path
      d="M8.94895 5.29837V3.86704C8.94895 2.1917 7.59029 0.833038 5.91495 0.833038C4.23962 0.825704 2.87562 2.1777 2.86829 3.8537V3.86704V5.29837"
      stroke-width="1.1"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M8.4555 13.1663H3.3615C1.9655 13.1663 0.833496 12.035 0.833496 10.6383V7.77898C0.833496 6.38231 1.9655 5.25098 3.3615 5.25098H8.4555C9.8515 5.25098 10.9835 6.38231 10.9835 7.77898V10.6383C10.9835 12.035 9.8515 13.1663 8.4555 13.1663Z"
      stroke-width="1.1"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M5.90865 8.46826V9.94893"
      stroke-width="1.1"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>

<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'LockIcon',
})
</script>
