<template>
    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="41" height="40" viewBox="0 0 41 40" fill="none">
        <rect x="0.463379" width="40" height="40" fill="url(#pattern0)"/>
        <defs>
        <pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1">
        <use xlink:href="#image0_3611_2533" transform="scale(0.02)"/>
        </pattern>
        <image id="image0_3611_2533" width="50" height="50" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAAEk0lEQVRoge2YW2xURRjHf3P21m4LpbQldbcKQgshGkK0eMFQNgqYtBAFIoFEpKLRBMMDLybyoBhRE41vWjUGJBjjJcW2wRpETVvkIomxGBMrhVag2HrpTWz30uWc8QEvu+z2nBkwKw/nl5yHb+b7zvf/dmbOzCy4uLi4uLi4ILI1Rta2VkvJGhAluRZkjxyysBq//GjVN5f3ZBQSWf3JToncnq3vGkEi5c6O5pVPpzamia1Z/fEagdiXW11XhgH3tzXVtaTYKUjjsZwrukIseDzVTitEGNac3Mq5CoSsSjW9aZ1SpNsOzDT7CJkDTJejJPDzq6eMk54qEsI/aUyeL868Gb2UFg4R8E4wEivi/EiIvpGQTuoMrVrCAQrkOOtiTSxPtBEyf87oTwg/x33VvBd8gC7v3H/abw79wIbqJqpv+JaAdyIjrm8kxMGuCI2ddcSS+bqy0hf70tWtPwKzJnOOJA6zbew1iuQFpZe3Blawu+Qhti7fRaTqqFLMcHQaL3++hWO91U6uZzqa6m7821AekY3RD9gcfQeBVA2hJnmUhStOEq7MHLnJmB4c5flVL9JwqJ7GzlXKcYazC9TGD/JIdK9WEQDx2wsIi37oscBUjzOE5ImaPdw977B6jJNDyBxg21iDuooUyo79Am8nLz1HNCoBhJA8uayB0sIRJX/HQh6N7sVHUktE1AgiQwaExb/PKQsy17gteb449Xe8r+Rru0amyj9Ymjiilx04PXcOCx7s1o7Lxr3z22k4VE90wv5LZjsiiyeO49GZ3H8xY8EwxMh84tqvwudJsmhmp6Of7YhUJnv1MwPlH/6UvcMD7AhoH0crS8/ScWqxrY/tiJRYw3oZnTCBuN6XD6Ck0FmH7YhIoX+SH/SWULpjTDvOVodC7bYjMmRM1046zRxFmv/tVWZo3Pl+ZzsiPd7Z2km90sR6QSIMK7OzwoBNPu13nh6c6ZzXrvOo/zZMPNpfLiORpQiA2UoHiTSSpo+vzy509LMt5IKYQltgCcsS7VrJo0YQ/8MWXv9lBZXoT7kD30cc9xBQ2Nl3BzeSRG86BK0oJ4/NTt/ZwwLytF5DLJnPnq/WK/k6FtLvKeeVKVv1FACVXT2Mv+m7dM5q199UpRS89NkWhsaLlfyVJu2BwD28VbAJqbGTBWSCgr4xEuN+uNOjHAdgSYNXOzbT1n2Xcozy6ns3fx3PTN3OqFGkJkYIGvPuY73YxRdnliCl2o8wOFbMUy3b2XeiTlUaoHlDBAjK2KWrbryNsNWf0R8T+XT4F9OSvzLtqnvTdd1suLWJRbM6s151z42E+bQrwr7OOuJJpcWUdkPULiSV683zVJj9FFujmHgY8JbT7akkLgKTxuT5ElSV9VI2ZYg8b4Lh6DTODYfp/71cNW3WQtI/v0JeRHEKAPR5KujzVGhljycDfNc/XysmK0JeTDXT1oi0jJ6rz5AjpDiVahqXGW/kVs1VYInXU820Qtqba5uR8jnQ/Jcht0gheLajpXZ/amPWBbFkzf5bDCnWIozS3GhTQ0h+Q8rG9ua6E/+3FhcXFxcXl2uSPwE2KngTbMgF4wAAAABJRU5ErkJggg=="/>
        </defs>
        
</svg>
</template>

<script>
    export default {
        name:"mastercard-icon",
        props:['width']
    }
</script>

