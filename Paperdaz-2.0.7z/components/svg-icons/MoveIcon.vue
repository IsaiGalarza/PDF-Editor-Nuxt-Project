<template>
  <svg
    width="15"
    height="15"
    viewBox="0 0 15 15"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="stroke-current"
  >
    <path
      d="M3.125 5.625L1.25 7.5L3.125 9.375"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M5.625 3.125L7.5 1.25L9.375 3.125"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M9.375 11.875L7.5 13.75L5.625 11.875"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M11.875 5.625L13.75 7.5L11.875 9.375"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path d="M1.25 7.5H13.75" stroke-linecap="round" stroke-linejoin="round" />
    <path
      d="M7.50385 1.25L7.50027 13.125"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'MoveIcon',
})
</script>
