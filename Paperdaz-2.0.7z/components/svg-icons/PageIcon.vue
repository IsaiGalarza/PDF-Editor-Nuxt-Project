<template>
<svg width="21" height="27" viewBox="0 0 21 27" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M9.28576 19C9.00843 19 8.74405 18.8892 8.56255 18.6953L6.27902 15.9951C5.93675 15.6291 5.8787 15.3087 6.27812 14.9951C6.67735 14.6811 7.05326 15.1289 7.39594 15.4951L9.28576 17.448L13.9402 11.4952C14.6712 10.5569 15.4363 11.0765 14.7021 12.0188L10.0606 18.6345C9.89034 18.8529 9.62004 18.9873 9.32768 18.9991C9.31356 18.9997 9.29968 19 9.28576 19Z" fill="#77B550"/>
    <path d="M6 5H3V24H18V5H15" stroke="#77B550" stroke-width="0.5"/>
    <path d="M14 1H7V6H14V1Z" stroke="#77B550" stroke-width="0.8"/>
    <path d="M6 3H1V26H20V3H15" stroke="#77B550" stroke-width="0.8"/>
    <path d="M12.5 2.5H8.5V4.5H12.5V2.5Z" stroke="#77B550" stroke-width="0.5"/>
</svg>
</template>

<script>
export default {}
</script>

<style></style>
