<template>
  <svg
    width="16"
    height="16"
    viewBox="0 0 42 34"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="fill-current"
  >
    <path
      d="M37.5857 0.333374H4.25236C1.93986 0.333374 0.106527 2.18754 0.106527 4.50004L0.0856934 29.5C0.0856934 31.8125 1.93986 33.6667 4.25236 33.6667H37.5857C39.8982 33.6667 41.7524 31.8125 41.7524 29.5V4.50004C41.7524 2.18754 39.8982 0.333374 37.5857 0.333374ZM37.5857 29.5H4.25236V17H37.5857V29.5ZM37.5857 8.66671H4.25236V4.50004H37.5857V8.66671Z"
    />
  </svg>
</template>

<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'PaymentCardIcon',
})
</script>
