<template>
  <svg
    :height="fontSize * hwRatio"
    :width="fontSize / hwRatio"
    viewBox="0 0 35 35"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="fill-current"
  >
    <path
      d="M26.388 0C25.6703 0 24.9711 0.276316 24.419 0.810526L20.5179 4.71579L30.2708 14.4974L34.1719 10.6289C35.276 9.50526 35.276 7.75526 34.1719 6.68684L28.3386 0.810526C27.7865 0.276316 27.0873 0 26.388 0ZM19.2114 6.02368L4.30599 20.9632L9.01682 21.4789L9.34805 25.6974L13.5436 26.0105L14.0773 30.7263L28.9826 15.7868L19.2114 6.02368ZM3.22029 22.6763L0 35L12.3291 31.7026L11.8875 27.7237L7.6367 27.4105L7.30547 23.1368"
    />
  </svg>
</template>

<script>
import mixins from 'vue-typed-mixins'
import IconSizeMixin from '~/mixins/IconSizeMixin'
export default mixins(IconSizeMixin).extend({
  name: 'PdfPenToolIcon',
  data() {
    return {
      hwRatio: 1,
    }
  },
})
</script>
