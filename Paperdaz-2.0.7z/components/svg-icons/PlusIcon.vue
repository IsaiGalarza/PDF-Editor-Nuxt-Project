<template>
  <svg
    width="36"
    height="37"
    viewBox="0 0 36 37"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M19.7662 17.2474H32.8572V20.2275H19.7662V33.638H16.8571V20.2275H3.76611V17.2474H16.8571V3.83691H19.7662V17.2474Z"
      fill="currentColor"
    />
  </svg>
</template>

<script>
export default {}
</script>

<style></style>
