<template>
  <svg
    width="30"
    height="22"
    viewBox="0 0 30 22"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
  >
    <path
      d="M11.5294 6.01562H1.56836V20.7812H11.5294H20.9371V15.3125"
      stroke="currentColor"
      stroke-width="2"
    />
    <path
      d="M9.31543 9.84375C9.31543 4.4072 13.7226 0 19.1592 0H19.3938C24.8303 0 29.2375 4.4072 29.2375 9.84375V9.84375C29.2375 15.2803 24.8303 19.6875 19.3938 19.6875H19.1592C13.7226 19.6875 9.31543 15.2803 9.31543 9.84375V9.84375Z"
      fill="url(#pattern0)"
    />
    <defs>
      <pattern
        id="pattern0"
        patternContentUnits="objectBoundingBox"
        width="1"
        height="1"
      >
        <use
          xlink:href="#image0_3707_2269"
          transform="translate(0.00588822) scale(0.0329408 0.0333333)"
        />
      </pattern>
      <image
        id="image0_3707_2269"
        width="30"
        height="30"
        xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAABmJLR0QA/wD/AP+gvaeTAAABHElEQVRIie3Uv0rDUBQH4E8RB8VBKKLo7qKD1MW5uOj7+AQO4uTm5OALCO6d6qDUUaEKOrpIF6k6CP4ZepUgaU0u5RakP7gQwj35TpKTMMoo5VJHE3Op4c+wWlgYBpwc/zQk/DfcEx+LBNawgXUsoxIuPtNj/zVqeIzB5rGLO/l39te6UnLap7CPl0gwuy6LolXcDgAsBW+iM0C00KOu4nmAaEt3Rn6SN9WzobvFHk094QznuME92uF8J2d/4Yk+yun4HafYxmSf2uhJXglItriB1SLFsSgcZwo/sIfxosX6vNN+mcZrpninBPidOi6U/FFsZdCTCDQ6BwHtYCkl3AjwYUoUHgJcSw2/BbiSApvIHDd1P6F2CniU/58vdUOtNN+oTgkAAAAASUVORK5CYII="
      />
    </defs>
  </svg>
</template>

<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'RequestIcon',
})
</script>
