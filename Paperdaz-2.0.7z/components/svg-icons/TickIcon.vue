<template>
  <svg
    width="43"
    height="26"
    viewBox="0 0 43 26"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="stroke-current"
  >
    <path d="M1.37402 15.5652L12.2321 23.7977L42.3007 1" stroke-width="2" />
  </svg>
</template>

<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'TickIcon',
})
</script>
