<template>
  <svg
    width="21"
    height="21"
    viewBox="0 0 21 21"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
  >
    <path
      d="M0.647461 10.4688C0.647461 5.0322 5.05466 0.625 10.4912 0.625H10.7258C16.1624 0.625 20.5696 5.0322 20.5696 10.4688C20.5696 15.9053 16.1624 20.3125 10.7258 20.3125H10.4912C5.05465 20.3125 0.647461 15.9053 0.647461 10.4688Z"
      fill="url(#pattern0)"
    />
    <defs>
      <pattern
        id="pattern0"
        patternContentUnits="objectBoundingBox"
        width="1"
        height="1"
      >
        <use
          xlink:href="#image0_3707_2268"
          transform="translate(0.00588822) scale(0.0329408 0.0333333)"
        />
      </pattern>
      <image
        id="image0_3707_2268"
        width="30"
        height="30"
        xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAABmJLR0QA/wD/AP+gvaeTAAAAtElEQVRIie2VQQ6CQAxFX8R7uPM4xsPgCTmFSzW6niUGBTezMnawLTIQecks+1+bzgD8G4Wjdg9sgeNAvXzNHah/Fb6L4Z3y1LFWTWWQSaf6JFhZulLSjeCYOQH/foMUntrx2d87p1xiMWOS4ssAYjFjkhNnE4s3UoEpowAa7G+4AdZSeGriJ3CzdBy5Ag+LGHx7TtYu4nc8H5FkbbaJ+9gALfqn1MZaFwd0/+YAlF7pwvx5Abo6e/T2cOSLAAAAAElFTkSuQmCC"
      />
    </defs>
  </svg>
</template>

<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'TrashCanSolidIcon',
})
</script>
