<template>
  <svg
    width="13"
    height="17"
    viewBox="0 0 13 17"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="fill-current"
  >
    <path
      d="M1.25 14.625C1.25 15.5875 2.0375 16.375 3 16.375H10C10.9625 16.375 11.75 15.5875 11.75 14.625V4.125H1.25V14.625ZM3.4025 8.395L4.63625 7.16125L6.5 9.01625L8.355 7.16125L9.58875 8.395L7.73375 10.25L9.58875 12.105L8.355 13.3388L6.5 11.4837L4.645 13.3388L3.41125 12.105L5.26625 10.25L3.4025 8.395ZM9.5625 1.5L8.6875 0.625H4.3125L3.4375 1.5H0.375V3.25H12.625V1.5H9.5625Z"
    />
  </svg>
</template>

<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'TrashXIcon',
})
</script>
