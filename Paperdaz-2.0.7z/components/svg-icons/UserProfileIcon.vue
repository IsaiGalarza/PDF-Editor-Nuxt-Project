<template>
  <svg
    width="16"
    height="20"
    viewBox="0 0 12 14"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="stroke-current"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M5.99125 9.23096C3.41284 9.23096 1.21094 9.6208 1.21094 11.1821C1.21094 12.7433 3.39887 13.1471 5.99125 13.1471C8.56967 13.1471 10.7709 12.7567 10.7709 11.196C10.7709 9.6354 8.58364 9.23096 5.99125 9.23096Z"
      stroke-width="1.2"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M5.98993 7.00408C7.68199 7.00408 9.05342 5.63202 9.05342 3.93996C9.05342 2.24789 7.68199 0.876465 5.98993 0.876465C4.29786 0.876465 2.9258 2.24789 2.9258 3.93996C2.92008 5.62631 4.28262 6.99837 5.96834 7.00408H5.98993Z"
      stroke-width="1.2"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>

<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'UserProfileIcon',
})
</script>
