export default {
     beforeCreate() {
       //@ts-ignore
      console.log(this.$route.params)
     },
}