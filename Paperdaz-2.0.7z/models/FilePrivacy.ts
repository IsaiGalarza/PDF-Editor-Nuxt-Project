enum FilePrivacy {
    PRIVATE = 'private',
    PUBLIC = 'public',
    DO_NOT_POST = "doNotPost"
  }
  
  export default FilePrivacy