enum Plan {
    YEARLY = 'yearly',
    MONTHLY= 'monthly'
  }
  
  export default Plan