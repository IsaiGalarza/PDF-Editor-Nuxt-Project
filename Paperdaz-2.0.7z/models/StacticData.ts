enum StaticData {
    MAX_LEAVES = 'max_leaves',
    LEAVES_PER_FILE= 'leaves_per_file',
    LEAVES_PER_SHARE= 'leaves_per_share'
  }
  
  export default StaticData