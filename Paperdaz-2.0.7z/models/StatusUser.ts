enum StatusUser {
    ACTIVE = 'active',
    SUSPENDED = 'suspended',
    EXPIRED = 'expired',
    PENDING = 'pending',
    DISABLE = 'disable'
  }
  
  export default StatusUser