enum TeamAccess {
    OWN_FILE = 'own_files',
    COMPANY_FILE = 'company_files',
  }
  
  export default TeamAccess