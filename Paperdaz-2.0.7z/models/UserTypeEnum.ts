enum UserTypeEnum {
  FREE = 'free_user',
  PAID = 'paid_user',
  ADMIN = 'admin',
  TEAM = "team_member",
  SUPER_ADMIN = 'super_admin',
}

export default UserTypeEnum
