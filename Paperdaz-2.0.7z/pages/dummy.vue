<template>
  <div>
    <button
      class="bg-paperdazgreen-300 h-10 text-white rounded shadow-2xl px-4"
      @click="$auth.logout()"
    >
      Logout
    </button>

    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea fugiat atque
      voluptas perferendis explicabo debitis iste cumque dolores non tempore
      temporibus veniam quibusdam unde natus illo a perspiciatis, ab minima!
    </p>
  </div>
</template>
<script>
import Vue from 'vue'
export default Vue.extend({
  name: 'DashboardPage',
  auth: false,
  layout: 'dashboard',
})
</script>
