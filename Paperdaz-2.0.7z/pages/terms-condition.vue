<template>
  <html>
    <head>
      <meta content="text/html; charset=UTF-8" http-equiv="content-type" />
    </head>
    <body class="c13 doc-content c-none">
      <p class="c10"><span class="c3 c15">TERMS AND CONDITIONS</span></p>
      <p class="c2"><span class="c3 c1">INTRODUCTION</span></p>
      <p class="c2" id="h.gjdgxs">
        <span class="c0">Welcome to </span
        ><span class="c4 c0"
          ><a class="c17" href="https://www.paperdaz.com"
            >www.paperdaz.com</a
          ></span
        ><span class="c3 c0"
          >. This &ldquo;Agreement&rdquo; jointly refers to all the terms,
          conditions, notices and instructions referenced or contained in this
          document (the &ldquo;Terms and Conditions&rdquo;) and every other
          operating rules, regulations and policies (including our Privacy
          Policy available on the Web App) and other necessary guidelines which
          we may occasionally publish on the Service.</span
        >
      </p>
      <p class="c2" id="h.30j0zll">
        <span class="c3 c0"
          >The &ldquo;Service&rdquo; collectively refers to the software, or Web
          App made available by Paperdaz, &ldquo;The User&rdquo;
          (&ldquo;You&rdquo; or &ldquo;Your&rdquo;) implies the person, entity
          or corporate organisation that has accessed or is currently using the
          Service.</span
        >
      </p>
      <p class="c2">
        <span class="c3 c0"
          >&ldquo;Paperdaz&rdquo; (&ldquo;We&rdquo; or &ldquo;Us&rdquo;) refers
          to Paperdaz, our partners, associates, subsidiaries, directors,
          licensors, contractors, agents, officers, and employees.</span
        >
      </p>
      <p class="c2" id="h.1fob9te"><span class="c3 c1">AGE LIMITATION</span></p>
      <p class="c2">
        <span class="c3 c0"
          >Children below the age of 18 years are not eligible to access or use
          the Service. To this end, our Services are not directed towards anyone
          under the age of 18. Also, we do not collect personally identifiable
          information from Users who we know to be less than 18 years old. We
          should be promptly notified if we have requested or collected
          personally identifiable information from users below 18 years of age
          and we will duly delete such information.</span
        >
      </p>
      <p class="c2 c5"><span class="c3 c1"></span></p>
      <p class="c2"><span class="c3 c1">PROVISIONS OF THE SERVICE</span></p>
      <ul class="c7 lst-kix_list_3-0 start">
        <li class="c14 c6 li-bullet-0">
          <span class="c3 c0"
            >You acknowledge and consent that we may make modifications to, or
            stop providing, the Service, or limit the use of the Service and/or,
            at any time without prior notification to you.</span
          >
        </li>
        <li class="c14 c6 li-bullet-0">
          <span class="c3 c0"
            >You are exclusively responsible for all data, mobile carrier, SMS,
            telecommunications and internet fees and bills sustained as a result
            of your use of the Service.</span
          >
        </li>
        <li class="c2 c6 li-bullet-0">
          <span class="c3 c0"
            >You acknowledge and consent that we can disable your account or
            deny you access to the Service, without prior notification to you,
            for any or no reason at all, including but not limited to any breach
            of these Terms and Conditions or if we speculate that you have
            accessed and used any portion of the Service to carry out any
            unlawful activity. If we disable your account, you may not be
            allowed to access the Service, your account details or any materials
            contained in your account.</span
          >
        </li>
      </ul>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2" id="h.3znysh7">
        <span class="c3 c1">LINKS TO EXTERNAL WEBSITES</span>
      </p>
      <p class="c2">
        <span class="c3 c0"
          >Our Service may include links or attachments to other websites and
          materials provided by third parties (&ldquo;Linked Websites&rdquo;).
          The purpose of the Linked Websites is to provide information only and
          are exclusively for your convenience. We exercise no control over,
          neither do we accept or claim any responsibility for the products or
          content of such Linked Websites. Also, we do not claim or accept any
          responsibility for the loss or damage that may arise from your use of
          the Linked Websites.</span
        >
      </p>
      <p class="c2">
        <span class="c3 c0"
          >If you decide to use the Linked Websites, you do so only at your sole
          risk and according to the terms and conditions, including the privacy
          policy of the Linked Websites.</span
        >
      </p>
      <p class="c2">
        <span class="c3 c0"
          >Our website may also contain promotions or advertisements from third
          parties. By permitting the third parties to advertise on our Services,
          we do not make any warranties or representations in respect or the
          products or the services advertised or promoted.</span
        >
      </p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2"><span class="c3 c1">INTELLECTUAL PROPERTY</span></p>
      <p class="c2">
        <span class="c0"
          >All intellectual property rights (including the various rights
          conferred on www.paperdaz.com by statute, common law and equity in and
          in relation to copyright, trademarks, patents, trade names, service
          marks and designs- referring to the &ldquo;look and feel&rdquo; and
          other visual or non-literal contents) whether registered or otherwise
          under our Services. These apply to all the text, design, graphics,
          photos, sounds, music, videos, software, and their arrangement and
          selection, and all compilations of software, underlying source code
          and software (scripts and applets) of our Services, are owned by or
          licensed to us. You shall not attempt to obtain or bypass any title to
          such intellectual property rights. To this end, </span
        ><span class="c3 c1">ALL RIGHTS ARE RESERVED.</span>
      </p>
      <p class="c2">
        <span class="c3 c0"
          >As a result, none of those mentioned above materials or content may
          be copied, reproduced, distributed, downloaded, republished, posted,
          displayed or transferred in any format or through any media, rented,
          sold or sub-licensed, create derivative works of, or exploited in any
          way without the prior written permission from us. Also, you may not
          modify, copy, reproduce, or distribute or use for commercial reasons
          any of the content or materials on our Services without the prior
          written permission from us.</span
        >
      </p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2"><span class="c3 c1">DISCLAIMERS</span></p>
      <p class="c2">
        <span class="c3 c0"
          >The service is provided by Paperdaz on &ldquo;as is&rdquo; and
          &ldquo;as available&rdquo; basis without any warranty whatsoever.
          Without limiting the preceding, we explicitly disclaim all warranties,
          whether implied or express or statutory, regarding the Service
          including without limitation to any warranty of merchantability,
          warranty of fitness for a specific purpose, security, title, accuracy,
          and non-violation.</span
        >
      </p>
      <p class="c2">
        <span class="c3 c0"
          >Paperdaz does not warrant that the Service will meet your specific
          requirements; that the Service will not be disrupted, that they will
          be secure, timely, or free from errors. Similarly, Paperdaz does not
          warrant that the information provided therein will be reliable,
          accurate or correct; that any errors or defects will be promptly
          corrected; that the Service will be available at any given location
          and time; or that they will be free of malware, viruses or other
          harmful codes.</span
        >
      </p>
      <p class="c2">
        <span class="c3 c0"
          >You assume full liability and risk of loss as a result of downloading
          or using of files, content, information or other material obtained
          from the Service.</span
        >
      </p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2"><span class="c3 c1">LIMITATION OF LIABILITY</span></p>
      <p class="c2">
        <span class="c3 c0"
          >You acknowledge and consent that Paperdaz will not be liable to you
          or any third party for any loss of profits, goodwill, use or data, or
          for any incidental, special, consequential, indirect or exemplary
          damages, that result from:</span
        >
      </p>
      <ul class="c7 lst-kix_list_1-0 start">
        <li class="c9 li-bullet-1">
          <span class="c3 c0"
            >the disclosure, use, or display of your content;</span
          >
        </li>
        <li class="c9 li-bullet-2">
          <span class="c3 c0">your use or failure to use the Service;</span>
        </li>
        <li class="c9 li-bullet-2">
          <span class="c3 c0"
            >any modification, discontinuance or suspension of any part of the
            Service;</span
          >
        </li>
        <li class="c9 li-bullet-2">
          <span class="c3 c0"
            >the general outlay of the Service or the systems or software that
            makes our service available;</span
          >
        </li>
        <li class="c9 li-bullet-1">
          <span class="c3 c0"
            >unsolicited access to or modifications of your transmissions or
            data;</span
          >
        </li>
        <li class="c9 li-bullet-2">
          <span class="c3 c0"
            >any other communications you initiated, or you received through the
            use of the Service; or</span
          >
        </li>
        <li class="c2 c18 li-bullet-1">
          <span class="c3 c0">any other issue involving the Service.</span>
        </li>
      </ul>
      <p class="c2">
        <span class="c3 c0"
          >Paperdaz liability is limited whether or otherwise we have been
          notified of the likely occurrence of such damages, and even if a
          resolution outlined in this Agreement failed its essential purpose.
          Paperdaz has no liability for any delay or failure due to matters
          beyond our rational control.</span
        >
      </p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2"><span class="c3 c1">COPYRIGHT VIOLATION</span></p>
      <p class="c2">
        <span class="c0"
          >If you have any reason to believe that any content of our Service
          breaches your copyright, please do contact us in compliance with the
          Digital Millennium Copyright Act Policy. If you are an accredited
          copyright owner and you have any reason to believe that any content on
          this website breaches your rights, please do contact us through our
          email</span
        ><span class="c0 c4">&nbsp;</span
        ><span class="c4 c0"
          ><a class="c17" href="mailto:mai@paperdaz.com"
            >mai@paperdaz.com</a
          ></span
        ><span class="c3 c0">.</span>
      </p>
      <p class="c2">
        <span class="c3 c0"
          >Please be informed that there may be legal repercussions for sending
          a frivolous notice of copyright breach. Before sending us such a
          request, you must consider legal points such as licensed use and fair
          uses.</span
        >
      </p>
      <p class="c2">
        <span class="c3 c0"
          >We will terminate the accounts of chronic violators of this
          policy.</span
        >
      </p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2"><span class="c3 c1">INDEMNIFICATION</span></p>
      <p class="c2">
        <span class="c3 c0"
          >You accept to indemnify us, defend us and hold us harmless from and
          against all liabilities, claims, and expenses, including reasonable
          attorney&rsquo;s fees, arising from your use of the Service, including
          but not limited to your breach of this Agreement, provided that
          we</span
        >
      </p>
      <ol class="c7 lst-kix_list_2-0 start" start="1">
        <li class="c6 c14 li-bullet-0">
          <span class="c3 c0"
            >promptly gives you prior notification of the demand, claim,
            proceeding or suit;</span
          >
        </li>
        <li class="c14 c6 li-bullet-0">
          <span class="c3 c0">gives you exclusive control of the </span
          ><span class="c0">defence</span
          ><span class="c3 c0"
            >&nbsp;and settlement of the demand, claim, proceeding or suit
            (given that you may not settle any demand, claim, proceeding or suit
            except the settlement unconditionally frees Paperdaz of all
            liability); and</span
          >
        </li>
        <li class="c2 c6 li-bullet-0">
          <span class="c3 c0"
            >makes available at your disposal all necessary assistance.</span
          >
        </li>
      </ol>
      <p class="c2 c5"><span class="c3 c1"></span></p>
      <p class="c2">
        <span class="c3 c1">CHANGES TO THESE TERMS AND CONDITIONS</span>
      </p>
      <p class="c2">
        <span class="c3 c0"
          >Paperdaz reserves the exclusive right, at its discretion to amend or
          modify these Terms and Conditions at any time and will update these
          Terms and Conditions in the event of such amendments and
          modifications. We will duly notify you of any material changes to this
          agreement at least 30 days before the amended Terms and Conditions
          become effective. For non-material amendments, your further use of the
          Service represents your consent to the revised Terms and Conditions.
        </span>
      </p>
      <p class="c2">
        <span class="c3 c0"
          >We reserve the right at any time, as we deem it necessary to amend or
          discontinue, temporarily or permanently, the Service (or any part of
          it) with or without notice.</span
        >
      </p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2"><span class="c3 c1">GOVERNING LAW</span></p>
      <p class="c2">
        <span class="c3 c0"
          >Except to the extent provided by the applicable law, otherwise, this
          Agreement between you and Paperdaz and any access to or use of the
          Service are governed by the Federal laws of Malaysia, without regard
          to provisions of the conflict of the law. You and Paperdaz consent to
          submit to the exclusive jurisdiction and venue of the courts located
          in Kuala Lumpur.</span
        >
      </p>
      <p class="c2 c5"><span class="c3 c1"></span></p>
      <p class="c2 c5"><span class="c3 c1"></span></p>
      <p class="c2"><span class="c3 c1">NON-ASSIGNABILITY</span></p>
      <p class="c2">
        <span class="c3 c0"
          >If any section of this Agreement is considered to be invalid and
          unenforceable, that portion of the Agreement will be interpreted to
          reflect the parties&rsquo; initial intent. The remaining sections will
          remain effective. Any failure by Paperdaz to enforce any provision of
          this Agreement will be deemed as a waiver of our right to enforce such
          provision. Our rights under this Agreement will suffice beyond the
          cancellation of this Agreement</span
        >
      </p>
      <hr style="page-break-before: always; display: none" />
      <p class="c5 c8"><span class="c3 c12"></span></p>
      <p class="c10" id="h.2et92p0">
        <span class="c3 c15">PRIVACY POLICY</span>
      </p>
      <p class="c2"><span class="c3 c1">INTRODUCTION</span></p>
      <p class="c2">
        <span class="c0"
          >The primary objective of this Privacy Policy Statement is to keep you
          informed about the practices of</span
        ><span class="c0 c16">&nbsp;</span><span class="c0 c11">Paperdaz</span
        ><span class="c3 c0">. </span>
      </p>
      <p class="c2">
        <span class="c3 c0"
          >The Privacy Policy relates to what information is submitted by or
          collected from the Users and how such information may be used, shared
          and stored.</span
        >
      </p>
      <p class="c2">
        <span class="c3 c0"
          >Paperdaz is the manager of all information. Paperdaz is also in
          charge of processing your personal information.</span
        >
      </p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2"><span class="c1 c3">EU GDPR COMPLIANCE STATEMENT</span></p>
      <p class="c2">
        <span class="c3 c0"
          >The policy explained below is binding according to the English and US
          Laws and including that which is a mandatory requirement for the EU
          General Data Protection Regulation (GDPR).</span
        >
      </p>
      <p class="c2">
        <span class="c3 c0"
          >In compliance with the requirements of the law, we enlighten you on
          your rights and our duties when it concerns the use and control of
          your information.</span
        >
      </p>
      <p class="c2">
        <span class="c3 c0"
          >We do not disclose, share or sell any information collected from
          Users through our Service to any third party except as specified and
          detailed in this Privacy Policy.</span
        >
      </p>
      <p class="c2">
        <span class="c3 c0"
          >In compliance with GDPR guidelines, Paperdaz is the &ldquo;data
          processor,&rdquo; and our Users are &ldquo;data controllers.&rdquo;
          Our Users are responsible for accepting information gathering
          requirements and meeting up with other privacy requirements for each
          User.</span
        >
      </p>
      <p class="c2">
        <span class="c3 c0"
          >We have built our Service in a manner that secures the privacy of our
          esteemed Users regarding their detail. We respect and value our
          User&rsquo;s right to privacy.</span
        >
      </p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2"><span class="c3 c1">INFORMATION THAT WE COLLECT</span></p>
      <p class="c2">
        <span class="c3 c0"
          >Personally Identifiable Information (PII) that we collect from
          individual Users are stated below:</span
        >
      </p>
      <p class="c2">
        <span class="c1">Information That You Submits: </span
        ><span class="c3 c0"
          >Upon your visit and using our website, or whenever we may collect
          information like your Email, Business name, Address, Country, First
          name, last name, phone number and other information as
          requested.</span
        >
      </p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2">
        <span class="c1">Communication Information: </span
        ><span class="c3 c0"
          >you acknowledge and agree that we may request for details of your
          communications or interactions when you contact our customer care
          team. These interactions or communications are recorded for the
          singular purpose of evaluation and training. This is to enhance and
          improve the quality of our Service delivery to you. You agree that any
          material you shared is processed along with what other users
          submitted.</span
        >
      </p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2">
        <span class="c3 c1">Information We Automatically Collect</span>
      </p>
      <p class="c2">
        <span class="c3 c0"
          >Our applicable third-party service providers and us will
          automatically collect information which may generally include your
          device Internet Protocol (IP) address, browser details, internet
          service provider (ISP), device operating system, and platform type.
        </span>
      </p>
      <p class="c2">
        <span class="c3 c0"
          >We may also involve the use of one or more cookies that may uniquely
          identify your account or browser, and date and time stamp from your
          browsing device and its software anytime you access or use the
          Service. You need to accept the use of cookies for you to have full
          access to the Service. Some browsers have been enabled to
          automatically accept cookies. Such can be disabled through the browser
          settings. Appropriate preference about cookies can be selected from
          the browser setting.</span
        >
      </p>
      <p class="c2">
        <span class="c3 c0"
          >We may also collect &ldquo;Usage Data&rdquo; which consist of
          information about your activity on and usage of the Service and the
          Services.</span
        >
      </p>
      <p class="c2">
        <span class="c1">Information about service usage: </span
        ><span class="c0"
          >we may collect details about your navigations and through the
          Service. The details collected may consist of information such as the
          pages you viewed, how you navigate through the service and its
          insights.
        </span>
      </p>
      <p class="c2">
        <span class="c1">Information about your location:</span
        ><span class="c0"
          >&nbsp;presently, we do not obtain information about your actual
          geographical location or corresponding coordinates, but we may collect
          such information in the future but not without your prior consent.
          Information such as the IP address that we harvested from Users can be
          used from time to time to estimate or evaluate a device&rsquo;s
          location.</span
        >
      </p>
      <p class="c2">
        <span class="c1">Third party information:</span
        ><span class="c0"
          >&nbsp;you accept and agree that we may collect some information that
          pertains to your use of our website, this information may be collected
          too. Appropriate third party agents may supply us with contact
          details, internet navigation details (which ascertains whether you are
          a robot or not through the way you navigate through the Service),
          information that checkmates fraud and partnering with financial
          institutions will also relay to us all transaction information and
          methods relating to the subscription or paid services that you use on
          the Service.</span
        >
      </p>
      <p class="c2">
        <span class="c3 c0"
          >You acknowledge and consent appropriately, that the Personal
          information gathered from your usage of our website may be linked with
          the information collected automatically from your browser and device.
          This is done providing you with a personalised and satisfactory
          experience notwithstanding your relations with us.</span
        >
      </p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2"><span class="c3 c1">OUR COOKIE POLICY </span></p>
      <p class="c2">
        <span class="c3 c0"
          >When you are visiting or accessing our Service for the first time, we
          will ask if you wish to allow the use of cookies on your browsing
          device. Users are permitted to choose to allow or disallow the use of
          cookies, and we may not use cookies on your first visit to the Service
          except for recording that you did not allow the use of cookies or for
          other such purposes. You consent that you will not be able to
          effectively use all the features and functions on our Service if you
          disable or disallow the usage of cookies on your browser or if you
          deactivate it from your browser settings.</span
        >
      </p>
      <p class="c5 c19"><span class="c3 c12"></span></p>
      <hr style="page-break-before: always; display: none" />
      <p class="c8 c5"><span class="c3 c1"></span></p>
      <p class="c2"><span class="c3 c1">DATA SECURITY</span></p>
      <p class="c2">
        <span class="c3 c0"
          >We have put in place adequate security measures to safeguard against
          misplacement, abuse, and tampering of information stored in our
          database.
        </span>
      </p>
      <p class="c2">
        <span class="c3 c0"
          >We engage the use of the appropriate level of care and control to
          ensure that we provide a secure transfer of data between your device
          and our servers. As a result, it is known that the transmission of
          data through the internet is not guaranteed to be 100% safe and
          secure. Hence, we will not ascertain the absolute security of any data
          transmitted through the internet. Therefore, we do not accept
          liability for such unintended disclosure.</span
        >
      </p>
      <p class="c2 c5"><span class="c3 c1"></span></p>
      <p class="c2"><span class="c3 c1">THIRD PARTY LINKS</span></p>
      <p class="c2">
        <span class="c3 c0"
          >Periodically, our Service may contain some third-party website links.
          If you chose to click or follow the provided link, in your sole
          discretion, please be notified that these websites or links have their
          privacy practices and policy. Therefore, we cannot be held responsible
          for the efficiency of such policies on the websites or links. Hence,
          you are advised to read their privacy policies and practices before
          you submit any personal information to the websites and links.</span
        >
      </p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2">
        <span class="c3 c1">MODIFICATION TO THIS PRIVACY POLICY</span>
      </p>
      <p class="c2">
        <span class="c3 c0"
          >You consent that we may modify, update or change this Privacy Policy
          document as we consider necessary, in our exclusive discretion.
          Similarly, periodic revisions will be carried out on this document.
          The User is admonished to review this Privacy Policy document
          regularly. Modifications, updates or revisions are considered
          effective once they have been published on this page.</span
        >
      </p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c2 c5"><span class="c3 c0"></span></p>
      <p class="c8 c5"><span class="c3 c20"></span></p>
    </body>
  </html>
</template>

<script>
export default {
  name: 'termsAndCondition',
  layout: 'landing',
  auth: false,
}
</script>

<style scoped lang="scss">
html {
  display: flex;
  justify-content: center;
  font-family: 'Poppins' !important;
}
html * {
  font-family: 'Poppins' !important;
}
.lst-kix_list_2-6 > li:before {
  content: '' counter(lst-ctn-kix_list_2-6, decimal) '. ';
}
.lst-kix_list_2-7 > li:before {
  content: '' counter(lst-ctn-kix_list_2-7, lower-latin) '. ';
}
.lst-kix_list_2-7 > li {
  counter-increment: lst-ctn-kix_list_2-7;
}
.lst-kix_list_2-1 > li {
  counter-increment: lst-ctn-kix_list_2-1;
}
ul.lst-kix_list_1-0 {
  list-style-type: none;
}
.lst-kix_list_2-4 > li:before {
  content: '' counter(lst-ctn-kix_list_2-4, lower-latin) '. ';
}
.lst-kix_list_2-5 > li:before {
  content: '' counter(lst-ctn-kix_list_2-5, lower-roman) '. ';
}
.lst-kix_list_2-8 > li:before {
  content: '' counter(lst-ctn-kix_list_2-8, lower-roman) '. ';
}
ol.lst-kix_list_2-6.start {
  counter-reset: lst-ctn-kix_list_2-6 0;
}
.lst-kix_list_3-0 > li:before {
  content: '\0025cf  ';
}
.lst-kix_list_3-1 > li:before {
  content: 'o  ';
}
.lst-kix_list_3-2 > li:before {
  content: '\0025aa  ';
}
ul.lst-kix_list_3-7 {
  list-style-type: none;
}
ul.lst-kix_list_3-8 {
  list-style-type: none;
}
ol.lst-kix_list_2-3.start {
  counter-reset: lst-ctn-kix_list_2-3 0;
}
ul.lst-kix_list_1-3 {
  list-style-type: none;
}
ul.lst-kix_list_3-1 {
  list-style-type: none;
}
.lst-kix_list_3-5 > li:before {
  content: '\0025aa  ';
}
ul.lst-kix_list_1-4 {
  list-style-type: none;
}
ul.lst-kix_list_3-2 {
  list-style-type: none;
}
ul.lst-kix_list_1-1 {
  list-style-type: none;
}
.lst-kix_list_3-4 > li:before {
  content: 'o  ';
}
ul.lst-kix_list_1-2 {
  list-style-type: none;
}
ul.lst-kix_list_3-0 {
  list-style-type: none;
}
ul.lst-kix_list_1-7 {
  list-style-type: none;
}
.lst-kix_list_3-3 > li:before {
  content: '\0025cf  ';
}
ul.lst-kix_list_3-5 {
  list-style-type: none;
}
ul.lst-kix_list_1-8 {
  list-style-type: none;
}
ul.lst-kix_list_3-6 {
  list-style-type: none;
}
ul.lst-kix_list_1-5 {
  list-style-type: none;
}
ul.lst-kix_list_3-3 {
  list-style-type: none;
}
ul.lst-kix_list_1-6 {
  list-style-type: none;
}
ul.lst-kix_list_3-4 {
  list-style-type: none;
}
ol.lst-kix_list_2-5.start {
  counter-reset: lst-ctn-kix_list_2-5 0;
}
.lst-kix_list_3-8 > li:before {
  content: '\0025aa  ';
}
.lst-kix_list_2-0 > li {
  counter-increment: lst-ctn-kix_list_2-0;
}
li.li-bullet-1:before {
  margin-left: -18pt;
  white-space: nowrap;
  display: inline-block;
  min-width: 18pt;
}
.lst-kix_list_4-0 > li:before {
  content: '\0025cf  ';
}
.lst-kix_list_2-3 > li {
  counter-increment: lst-ctn-kix_list_2-3;
}
.lst-kix_list_2-6 > li {
  counter-increment: lst-ctn-kix_list_2-6;
}
.lst-kix_list_4-1 > li:before {
  content: 'o  ';
}
.lst-kix_list_3-6 > li:before {
  content: '\0025cf  ';
}
.lst-kix_list_3-7 > li:before {
  content: 'o  ';
}
.lst-kix_list_4-4 > li:before {
  content: 'o  ';
}
ol.lst-kix_list_2-2.start {
  counter-reset: lst-ctn-kix_list_2-2 0;
}
.lst-kix_list_4-3 > li:before {
  content: '\0025cf  ';
}
.lst-kix_list_4-5 > li:before {
  content: '\0025aa  ';
}
.lst-kix_list_4-2 > li:before {
  content: '\0025aa  ';
}
.lst-kix_list_4-6 > li:before {
  content: '\0025cf  ';
}
ol.lst-kix_list_2-2 {
  list-style-type: none;
}
ol.lst-kix_list_2-3 {
  list-style-type: none;
}
ol.lst-kix_list_2-4 {
  list-style-type: none;
}
ol.lst-kix_list_2-5 {
  list-style-type: none;
}
ol.lst-kix_list_2-0 {
  list-style-type: none;
}
.lst-kix_list_2-4 > li {
  counter-increment: lst-ctn-kix_list_2-4;
}
ol.lst-kix_list_2-1 {
  list-style-type: none;
}
.lst-kix_list_4-8 > li:before {
  content: '\0025aa  ';
}
.lst-kix_list_4-7 > li:before {
  content: 'o  ';
}
ul.lst-kix_list_4-8 {
  list-style-type: none;
}
ul.lst-kix_list_4-6 {
  list-style-type: none;
}
ul.lst-kix_list_4-7 {
  list-style-type: none;
}
ol.lst-kix_list_2-8.start {
  counter-reset: lst-ctn-kix_list_2-8 0;
}
ul.lst-kix_list_4-0 {
  list-style-type: none;
}
ul.lst-kix_list_4-1 {
  list-style-type: none;
}
.lst-kix_list_1-0 > li:before {
  content: '\0025cf  ';
}
ul.lst-kix_list_4-4 {
  list-style-type: none;
}
ol.lst-kix_list_2-6 {
  list-style-type: none;
}
ul.lst-kix_list_4-5 {
  list-style-type: none;
}
.lst-kix_list_1-1 > li:before {
  content: 'o  ';
}
.lst-kix_list_1-2 > li:before {
  content: '\0025aa  ';
}
ol.lst-kix_list_2-0.start {
  counter-reset: lst-ctn-kix_list_2-0 0;
}
ol.lst-kix_list_2-7 {
  list-style-type: none;
}
ul.lst-kix_list_4-2 {
  list-style-type: none;
}
ol.lst-kix_list_2-8 {
  list-style-type: none;
}
ul.lst-kix_list_4-3 {
  list-style-type: none;
}
.lst-kix_list_1-3 > li:before {
  content: '\0025cf  ';
}
.lst-kix_list_1-4 > li:before {
  content: 'o  ';
}
.lst-kix_list_1-7 > li:before {
  content: 'o  ';
}
ol.lst-kix_list_2-7.start {
  counter-reset: lst-ctn-kix_list_2-7 0;
}
.lst-kix_list_1-5 > li:before {
  content: '\0025aa  ';
}
.lst-kix_list_1-6 > li:before {
  content: '\0025cf  ';
}
li.li-bullet-0:before {
  margin-left: -28.4pt;
  white-space: nowrap;
  display: inline-block;
  min-width: 28.4pt;
}
li.li-bullet-2:before {
  margin-left: -18pt;
  white-space: nowrap;
  display: inline-block;
  min-width: 18pt;
}
.lst-kix_list_2-0 > li:before {
  content: '' counter(lst-ctn-kix_list_2-0, lower-roman) '. ';
}
.lst-kix_list_2-1 > li:before {
  content: '' counter(lst-ctn-kix_list_2-1, lower-latin) '. ';
}
ol.lst-kix_list_2-1.start {
  counter-reset: lst-ctn-kix_list_2-1 0;
}
.lst-kix_list_2-5 > li {
  counter-increment: lst-ctn-kix_list_2-5;
}
.lst-kix_list_2-8 > li {
  counter-increment: lst-ctn-kix_list_2-8;
}
.lst-kix_list_1-8 > li:before {
  content: '\0025aa  ';
}
.lst-kix_list_2-2 > li:before {
  content: '' counter(lst-ctn-kix_list_2-2, lower-roman) '. ';
}
.lst-kix_list_2-3 > li:before {
  content: '' counter(lst-ctn-kix_list_2-3, decimal) '. ';
}
.lst-kix_list_2-2 > li {
  counter-increment: lst-ctn-kix_list_2-2;
}
ol.lst-kix_list_2-4.start {
  counter-reset: lst-ctn-kix_list_2-4 0;
}
ol {
  margin: 0;
  padding: 0;
}
table td,
table th {
  padding: 0;
}
.c9 {
  margin-left: 36pt;
  padding-top: 0pt;
  padding-left: 0pt;
  padding-bottom: 0pt;
  line-height: 1.5;
  orphans: 2;
  widows: 2;
  text-align: justify;
}
.c10 {
  padding-top: 0pt;
  padding-bottom: 4pt;
  line-height: 1.5;
  orphans: 2;
  widows: 2;
  text-align: center;
}
.c8 {
  padding-top: 0pt;
  padding-bottom: 8pt;
  line-height: 1.0791666666666666;
  orphans: 2;
  widows: 2;
  text-align: left;
}
.c19 {
  padding-top: 0pt;
  padding-bottom: 8pt;
  line-height: 1.5;
  orphans: 2;
  widows: 2;
  text-align: left;
}
.c2 {
  padding-top: 0pt;
  padding-bottom: 4pt;
  line-height: 1.5;
  orphans: 2;
  widows: 2;
  text-align: justify;
}
.c14 {
  padding-top: 0pt;
  padding-bottom: 0pt;
  line-height: 1.5;
  orphans: 2;
  widows: 2;
  text-align: justify;
}
.c3 {
  color: #000000;
  text-decoration: none;
  vertical-align: baseline;
  font-style: normal;
}
.c4 {
  -webkit-text-decoration-skip: none;
  color: #0563c1;
  text-decoration: underline;
  text-decoration-skip-ink: none;
}
.c13 {
  background-color: #ffffff;
  width: 100%;
  max-width: 1080px;
  padding: 72pt 1em 72pt 1em;
}
.c-none {
  background-color: transparent !important;
  width: 100% !important;
}
.c15 {
  font-weight: 700;
  font-size: 14pt;
}
.c0 {
  font-size: 12pt;
  font-weight: 400;
}
.c12 {
  font-weight: 400;
  font-size: 13pt;
}
.c1 {
  font-size: 12pt;
  font-weight: 700;
}
.c20 {
  font-weight: 400;
  font-size: 11pt;
}
.c17 {
  color: inherit;
  text-decoration: inherit;
}
.c7 {
  padding: 0;
  margin: 0;
}
.c18 {
  margin-left: 36pt;
  padding-left: 0pt;
}
.c11 {
  color: #000000;
  text-decoration: none;
}
.c16 {
  color: #0563c1;
  text-decoration: none;
}
.c6 {
  margin-left: 46.4pt;
  padding-left: 10.4pt;
}
.c5 {
  height: 11pt;
}
.title {
  padding-top: 24pt;
  color: #000000;
  font-weight: 700;
  font-size: 36pt;
  padding-bottom: 6pt;
  line-height: 1.0791666666666666;
  page-break-after: avoid;
  orphans: 2;
  widows: 2;
  text-align: left;
}
.subtitle {
  padding-top: 18pt;
  color: #666666;
  font-size: 24pt;
  padding-bottom: 4pt;
  line-height: 1.0791666666666666;
  page-break-after: avoid;
  font-style: italic;
  orphans: 2;
  widows: 2;
  text-align: left;
}
li {
  color: #000000;
  font-size: 11pt;
}
p {
  margin: 0;
  color: #000000;
  font-size: 11pt;
}
h1 {
  padding-top: 24pt;
  color: #000000;
  font-weight: 700;
  font-size: 24pt;
  padding-bottom: 6pt;
  line-height: 1.0791666666666666;
  page-break-after: avoid;
  orphans: 2;
  widows: 2;
  text-align: left;
}
h2 {
  padding-top: 18pt;
  color: #000000;
  font-weight: 700;
  font-size: 18pt;
  padding-bottom: 4pt;
  line-height: 1.0791666666666666;
  page-break-after: avoid;
  orphans: 2;
  widows: 2;
  text-align: left;
}
h3 {
  padding-top: 14pt;
  color: #000000;
  font-weight: 700;
  font-size: 14pt;
  padding-bottom: 4pt;
  line-height: 1.0791666666666666;
  page-break-after: avoid;
  orphans: 2;
  widows: 2;
  text-align: left;
}
h4 {
  padding-top: 12pt;
  color: #000000;
  font-weight: 700;
  font-size: 12pt;
  padding-bottom: 2pt;
  line-height: 1.0791666666666666;
  page-break-after: avoid;
  orphans: 2;
  widows: 2;
  text-align: left;
}
h5 {
  padding-top: 11pt;
  color: #000000;
  font-weight: 700;
  font-size: 11pt;
  padding-bottom: 2pt;
  line-height: 1.0791666666666666;
  page-break-after: avoid;
  orphans: 2;
  widows: 2;
  text-align: left;
}
h6 {
  padding-top: 10pt;
  color: #000000;
  font-weight: 700;
  font-size: 10pt;
  padding-bottom: 2pt;
  line-height: 1.0791666666666666;
  page-break-after: avoid;
  orphans: 2;
  widows: 2;
  text-align: left;
}
</style>
