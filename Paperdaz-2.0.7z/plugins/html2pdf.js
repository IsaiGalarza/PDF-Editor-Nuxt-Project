import Vue from 'vue'
// your imported custom plugin or in this scenario the 'vue-session' plugin
import * as html2pdf from 'html2pdf.js'

window.html2pdf = html2pdf
