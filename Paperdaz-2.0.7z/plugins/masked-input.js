import Vue from 'vue'
import MaskedInput from 'vue-masked-input'

Vue.use(MaskedInput)