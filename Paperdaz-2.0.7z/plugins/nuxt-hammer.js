import Vue from 'vue'
import { NuxtHammer } from 'nuxt-hammer'

Vue.use(NuxtHammer)
