import Vue from 'vue'

import Paginate from 'vuejs-paginate'
Vue.component('paginate', Paginate)