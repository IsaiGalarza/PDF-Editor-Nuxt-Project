import Vue from 'vue';
import VueCarousel from 'vue-carousel';
Vue.use(VueCarousel);