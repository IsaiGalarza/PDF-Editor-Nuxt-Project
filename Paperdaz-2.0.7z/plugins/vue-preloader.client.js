import Vue from 'vue';
import loader from 'vue-ui-preloader';
Vue.use(loader);