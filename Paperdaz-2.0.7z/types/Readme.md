 
 
 # to get the distance between the container of the paperlink annotation and the annotation along the x-axis
axisX

# to get the distance between the container of the paperlink annotation and the annotation along the y-axis
axisY

# to get the length of the paperlink annotation
length

# to get element which houses the pdf pages
elem

# attribute gotten from an annotation( signature & initial ) to check if sign and initials are uploaded
uploaded

# the main javascript script object which stores all value gotten from scrapping data   
parent

# the offset gotten from a PDF along x and y axis mostly zero(0) but have value in rare PDF
pdfOffset_y
pdfOffset_x

# te url of the loaded PDF in file manager
 pdf_url

# Dimension of the PDF in width and height
 pdfWidth
 pdfHeight 

 #  Type of format to be sent to the back end
  option

# the distance between the annotation container and the end of an annotation along the x-axis
 axisX2

 # the distance between the annotation container and the end of an annotation along the y-axis
 axisY2

 # getting the dimensions of an annotation
 svgWidth
 svgHeight

 # thetext content of an annotation 
  tools

 # getting the scale factor of an annotation in paperlink mostly ( image )
 elemScale

 # the name of the input-- for input scraped element
 fieldName

 # the value gotten from the input field
  value