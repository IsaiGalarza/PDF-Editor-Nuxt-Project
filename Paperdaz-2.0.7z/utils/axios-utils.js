

 export const FAQ_URL="http://paperdaz-be.herokuapp.com/api/v2/faqcategory"
